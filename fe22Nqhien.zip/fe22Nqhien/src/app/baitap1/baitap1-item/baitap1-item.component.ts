import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-baitap1-item',
  templateUrl: './baitap1-item.component.html',
  styleUrls: ['./baitap1-item.component.scss']
})
export class Baitap1ItemComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
