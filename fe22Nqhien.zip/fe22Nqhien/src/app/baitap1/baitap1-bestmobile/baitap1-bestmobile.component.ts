import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-baitap1-bestmobile',
  templateUrl: './baitap1-bestmobile.component.html',
  styleUrls: ['./baitap1-bestmobile.component.scss']
})
export class Baitap1BestmobileComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
