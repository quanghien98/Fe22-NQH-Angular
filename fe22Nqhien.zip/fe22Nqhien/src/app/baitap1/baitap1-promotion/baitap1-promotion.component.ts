import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-baitap1-promotion',
  templateUrl: './baitap1-promotion.component.html',
  styleUrls: ['./baitap1-promotion.component.scss']
})
export class Baitap1PromotionComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
