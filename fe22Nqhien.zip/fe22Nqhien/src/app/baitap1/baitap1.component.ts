import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-baitap1',
  templateUrl: './baitap1.component.html',
  styleUrls: ['./baitap1.component.scss']
})
export class Baitap1Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
