import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-baitap1-bestlaptop',
  templateUrl: './baitap1-bestlaptop.component.html',
  styleUrls: ['./baitap1-bestlaptop.component.scss']
})
export class Baitap1BestlaptopComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
