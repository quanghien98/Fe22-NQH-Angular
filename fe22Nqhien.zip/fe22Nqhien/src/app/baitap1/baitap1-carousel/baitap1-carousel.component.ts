import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-baitap1-carousel',
  templateUrl: './baitap1-carousel.component.html',
  styleUrls: ['./baitap1-carousel.component.scss']
})
export class Baitap1CarouselComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
